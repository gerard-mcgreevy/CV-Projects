require(`dotenv`).config({path:`./config/.env`})

const express = require(`express`)
const app = express()
const mongoose = require(`mongoose`)
const createError = require(`http-errors`)

app.use(require(`body-parser`).json())
app.use(require(`cors`)({credentials: true, origin: process.env.LOCAL_HOST}))
app.use(`/uploads`, express.static(process.env.UPLOADED_FILES_FOLDER))

mongoose.connect(process.env.DB_CONNECTION_STRING)
.then(() => console.log(`Connected to MongoDB`))
.catch(err => console.log(err))

app.use(require(`./routes/products`))
app.use(require(`./routes/users`))
app.use(require(`./routes/orders`))

app.listen(process.env.SERVER_PORT, () =>
{
    console.log(`Connected to port ` + process.env.SERVER_PORT)
})

app.use((req, res, next) => {next(createError(404))})

app.use(function (err, req, res, next)
{
    console.error(err.message)
    if (!err.statusCode)
    {
        err.statusCode = 500
    }
    res.status(err.statusCode).send(err.message)
})
