const jwt = require(`jsonwebtoken`)
const fs = require(`fs`)
const createError = require(`http-errors`)

const JWT_PRIVATE_KEY = fs.readFileSync(process.env.JWT_PRIVATE_KEY_FILENAME, `utf8`)

const verifyToken = (req, res, next) =>
{
    const authHeader = req.headers.authorization

    if(!authHeader)
    {
        next(createError(401, `Not logged in`))
    }
    else
    {
        jwt.verify(authHeader.split(` `)[1], JWT_PRIVATE_KEY, (err, decoded) =>
        {
            if(err)
            {
                next(createError(401, `Not logged in`))
            }
            else
            {
                req.tokenData = decoded
                next()
            }
        })
    }
}

const requireAdmin = (req, res, next) =>
{
    verifyToken(req, res, () =>
    {
        if(req.tokenData.accessLevel >= parseInt(process.env.ACCESS_LEVEL_ADMIN))
        {
            next()
        }
        else
        {
            next(createError(403, `Administrator access required`))
        }
    })
}

module.exports = {verifyToken, requireAdmin, JWT_PRIVATE_KEY}
