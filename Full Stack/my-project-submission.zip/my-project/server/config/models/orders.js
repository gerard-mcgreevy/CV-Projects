const mongoose = require(`mongoose`)

let orderItemSchema = new mongoose.Schema(
    {
        product: {type: mongoose.Schema.Types.ObjectId, ref: `products`, required: true},
        name: {type: String, required: true},
        quantity: {type: Number, required: true, min: 1},
        priceAtPurchase: {type: Number, required: true, min: 0}
    },
    {
        _id: false
    })

let ordersSchema = new mongoose.Schema(
    {
        user: {type: mongoose.Schema.Types.ObjectId, ref: `users`, default: null},
        contactName: {type: String, required: true},
        contactEmail: {type: String, required: true, match: /^[^@]+@[^@]+\.[a-zA-Z]{2,6}$/},
        items: {type: [orderItemSchema], required: true},
        totalPrice: {type: Number, required: true, min: 0},
        status: {type: String, enum: [`paid`, `returned`], default: `paid`},
        createdAt: {type: Date, default: Date.now}
    },
    {
        collection: `orders`
    })

module.exports = mongoose.model(`orders`, ordersSchema)
