const mongoose = require(`mongoose`)

let productsSchema = new mongoose.Schema(
    {
        name: {type: String, required: true},
        setNumber: {type: String, required: true},
        theme: {type: String, required: true},
        description: {type: String, required: true},
        pieceCount: {type: Number, required: true, min: 1},
        price: {type: Number, required: true, min: 0},
        stock: {type: Number, required: true, min: 0, default: 0},
        imageFilenames: {type: [String], default: []}
    },
    {
        collection: `products`
    })

module.exports = mongoose.model(`products`, productsSchema)
