const router = require(`express`).Router()
const createError = require(`http-errors`)
const fs = require(`fs`)
const multer = require(`multer`)

const productsModel = require(`../config/models/products`)
const {requireAdmin} = require(`../config/verifyToken`)

const upload = multer({dest: process.env.UPLOADED_FILES_FOLDER})

const VALID_IMAGE_TYPES = [`image/png`, `image/jpg`, `image/jpeg`]

const deleteFiles = filenames =>
{
    filenames.forEach(filename => fs.unlink(`${process.env.UPLOADED_FILES_FOLDER}/${filename}`, () => {}))
}

router.get(`/products`, (req, res, next) =>
{
    let filter = {}

    if(req.query.search)
    {
        filter.name = {$regex: req.query.search, $options: `i`}
    }

    if(req.query.theme && req.query.theme !== `All Themes`)
    {
        filter.theme = req.query.theme
    }

    const sortField = req.query.sortBy ? req.query.sortBy : `name`
    const sortDirection = req.query.sortDirection === `desc` ? -1 : 1

    productsModel.find(filter).sort({[sortField]: sortDirection})
    .then(data => res.json(data))
    .catch(err => next(createError(500, `Could not retrieve products`)))
})

router.get(`/products/:id`, (req, res, next) =>
{
    productsModel.findById(req.params.id)
    .then(data =>
    {
        if(!data)
        {
            next(createError(404, `Product not found`))
        }
        else
        {
            res.json(data)
        }
    })
    .catch(err => next(createError(404, `Product not found`)))
})

router.post(`/products`, requireAdmin, upload.array(`images`, 6), (req, res, next) =>
{
    const invalidFile = req.files.find(file => !VALID_IMAGE_TYPES.includes(file.mimetype))

    if(!req.body.name || !req.body.setNumber || !req.body.theme || !req.body.description)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Name, set number, theme and description are required`))
    }
    else if(isNaN(req.body.price) || Number(req.body.price) < 0)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Price must be a positive number`))
    }
    else if(isNaN(req.body.stock) || Number(req.body.stock) < 0)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Stock must be a positive number`))
    }
    else if(invalidFile)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Only .png, .jpg and .jpeg images are accepted`))
    }
    else
    {
        productsModel.create({
            name: req.body.name,
            setNumber: req.body.setNumber,
            theme: req.body.theme,
            description: req.body.description,
            pieceCount: req.body.pieceCount,
            price: req.body.price,
            stock: req.body.stock,
            imageFilenames: req.files.map(file => file.filename)
        })
        .then(data => res.json(data))
        .catch(err =>
        {
            deleteFiles(req.files.map(file => file.filename))
            next(createError(400, err.message))
        })
    }
})

router.put(`/products/:id`, requireAdmin, upload.array(`images`, 6), (req, res, next) =>
{
    const invalidFile = req.files.find(file => !VALID_IMAGE_TYPES.includes(file.mimetype))

    if(!req.body.name || !req.body.setNumber || !req.body.theme || !req.body.description)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Name, set number, theme and description are required`))
    }
    else if(isNaN(req.body.price) || Number(req.body.price) < 0)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Price must be a positive number`))
    }
    else if(invalidFile)
    {
        deleteFiles(req.files.map(file => file.filename))
        next(createError(400, `Only .png, .jpg and .jpeg images are accepted`))
    }
    else
    {
        productsModel.findById(req.params.id)
        .then(existingData =>
        {
            if(!existingData)
            {
                deleteFiles(req.files.map(file => file.filename))
                next(createError(404, `Product not found`))
            }
            else
            {
                const removeFilenames = req.body.removeImageFilenames ? JSON.parse(req.body.removeImageFilenames) : []
                const remainingFilenames = existingData.imageFilenames.filter(filename => !removeFilenames.includes(filename))
                const newFilenames = req.files.map(file => file.filename)

                productsModel.findByIdAndUpdate(req.params.id, {
                    name: req.body.name,
                    setNumber: req.body.setNumber,
                    theme: req.body.theme,
                    description: req.body.description,
                    pieceCount: req.body.pieceCount,
                    price: req.body.price,
                    imageFilenames: [...remainingFilenames, ...newFilenames]
                }, {new: true, runValidators: true})
                .then(data =>
                {
                    deleteFiles(removeFilenames)
                    res.json(data)
                })
                .catch(err =>
                {
                    deleteFiles(newFilenames)
                    next(createError(400, err.message))
                })
            }
        })
        .catch(err => next(createError(500, `Product was not updated`)))
    }
})

router.patch(`/products/:id/stock`, requireAdmin, (req, res, next) =>
{
    if(isNaN(req.body.stock) || Number(req.body.stock) < 0)
    {
        next(createError(400, `Stock must be a positive number`))
    }
    else
    {
        productsModel.findByIdAndUpdate(req.params.id, {stock: req.body.stock}, {new: true, runValidators: true})
        .then(data =>
        {
            if(!data)
            {
                next(createError(404, `Product not found`))
            }
            else
            {
                res.json(data)
            }
        })
        .catch(err => next(createError(400, err.message)))
    }
})

router.delete(`/products/:id`, requireAdmin, (req, res, next) =>
{
    productsModel.findByIdAndDelete(req.params.id)
    .then(data =>
    {
        if(!data)
        {
            next(createError(404, `Product not found`))
        }
        else
        {
            deleteFiles(data.imageFilenames)
            res.json(data)
        }
    })
    .catch(err => next(createError(500, `Product was not deleted`)))
})

module.exports = router
