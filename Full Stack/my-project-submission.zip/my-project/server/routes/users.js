const router = require(`express`).Router()
const createError = require(`http-errors`)
const fs = require(`fs`)
const bcrypt = require(`bcryptjs`)
const jwt = require(`jsonwebtoken`)
const multer = require(`multer`)

const usersModel = require(`../config/models/users`)
const {verifyToken, requireAdmin, JWT_PRIVATE_KEY} = require(`../config/verifyToken`)

const upload = multer({dest: process.env.UPLOADED_FILES_FOLDER})

const EMAIL_PATTERN = /^[^@]+@[^@]+\.[a-zA-Z]{2,6}$/
const PASSWORD_PATTERN = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[£!#€$%^&*]).{10,}$/

const respondWithSession = (res, data) =>
{
    const token = jwt.sign({id: data._id, email: data.email, accessLevel: data.accessLevel}, JWT_PRIVATE_KEY, {algorithm: `HS256`, expiresIn: process.env.JWT_EXPIRY})

    if(data.profilePhotoFilename)
    {
        fs.readFile(`${process.env.UPLOADED_FILES_FOLDER}/${data.profilePhotoFilename}`, `base64`, (err, fileData) =>
        {
            res.json({id: data._id, name: data.name, email: data.email, accessLevel: data.accessLevel, profilePhoto: fileData, token: token})
        })
    }
    else
    {
        res.json({id: data._id, name: data.name, email: data.email, accessLevel: data.accessLevel, profilePhoto: null, token: token})
    }
}

router.post(`/users/register/:name/:email/:password`, upload.single(`profilePhoto`), (req, res, next) =>
{
    if(!req.params.name)
    {
        next(createError(400, `Name is required`))
    }
    else if(!EMAIL_PATTERN.test(req.params.email))
    {
        next(createError(400, `Invalid email format`))
    }
    else if(!PASSWORD_PATTERN.test(req.params.password))
    {
        next(createError(400, `Password must be at least ten characters long and contain a lowercase letter, an uppercase letter, a digit and one of the following characters (£!#€$%^&*)`))
    }
    else if(req.file && req.file.mimetype !== `image/png` && req.file.mimetype !== `image/jpg` && req.file.mimetype !== `image/jpeg`)
    {
        fs.unlink(`${process.env.UPLOADED_FILES_FOLDER}/${req.file.filename}`, () =>
        {
            next(createError(400, `Only .png, .jpg and .jpeg format accepted for a profile photo`))
        })
    }
    else
    {
        usersModel.findOne({email: req.params.email})
        .then(existingUser =>
        {
            if(existingUser)
            {
                next(createError(409, `A user with this email already exists`))
            }
            else
            {
                bcrypt.hash(req.params.password, parseInt(process.env.PASSWORD_HASH_SALT_ROUNDS), (err, hash) =>
                {
                    usersModel.create({
                        name: req.params.name,
                        email: req.params.email,
                        password: hash,
                        profilePhotoFilename: req.file ? req.file.filename : ``
                    })
                    .then(data => respondWithSession(res, data))
                    .catch(err => next(createError(400, err.message)))
                })
            }
        })
        .catch(err => next(createError(500, `Registration failed`)))
    }
})

router.post(`/users/login/:email/:password`, (req, res, next) =>
{
    usersModel.findOne({email: req.params.email})
    .then(data =>
    {
        if(!data)
        {
            next(createError(401, `Invalid email or password`))
        }
        else
        {
            bcrypt.compare(req.params.password, data.password, (err, result) =>
            {
                if(result)
                {
                    respondWithSession(res, data)
                }
                else
                {
                    next(createError(401, `Invalid email or password`))
                }
            })
        }
    })
    .catch(err => next(createError(500, `Login failed`)))
})

router.post(`/users/logout`, (req, res) =>
{
    res.json({})
})

router.post(`/users/refresh_token`, verifyToken, (req, res, next) =>
{
    usersModel.findById(req.tokenData.id)
    .then(data =>
    {
        if(!data)
        {
            next(createError(401, `Not logged in`))
        }
        else
        {
            respondWithSession(res, data)
        }
    })
    .catch(err => next(createError(401, `Not logged in`)))
})

router.get(`/users`, requireAdmin, (req, res, next) =>
{
    usersModel.find({}, `-password`)
    .then(data => res.json(data))
    .catch(err => next(createError(500, `Could not retrieve users`)))
})

router.put(`/users/:id`, verifyToken, upload.single(`profilePhoto`), (req, res, next) =>
{
    if(req.tokenData.id !== req.params.id)
    {
        next(createError(403, `You can only edit your own profile`))
    }
    else if(!EMAIL_PATTERN.test(req.body.email))
    {
        next(createError(400, `Invalid email format`))
    }
    else if(req.file && req.file.mimetype !== `image/png` && req.file.mimetype !== `image/jpg` && req.file.mimetype !== `image/jpeg`)
    {
        fs.unlink(`${process.env.UPLOADED_FILES_FOLDER}/${req.file.filename}`, () =>
        {
            next(createError(400, `Only .png, .jpg and .jpeg format accepted for a profile photo`))
        })
    }
    else
    {
        usersModel.findById(req.params.id)
        .then(existingData =>
        {
            const updatedFields = {
                name: req.body.name,
                email: req.body.email
            }

            if(req.file)
            {
                updatedFields.profilePhotoFilename = req.file.filename
            }

            usersModel.findByIdAndUpdate(req.params.id, updatedFields, {new: true, runValidators: true})
            .then(data =>
            {
                if(req.file && existingData.profilePhotoFilename)
                {
                    fs.unlink(`${process.env.UPLOADED_FILES_FOLDER}/${existingData.profilePhotoFilename}`, () => respondWithSession(res, data))
                }
                else
                {
                    respondWithSession(res, data)
                }
            })
            .catch(err => next(createError(400, err.message)))
        })
        .catch(err => next(createError(500, `Profile was not updated`)))
    }
})

router.delete(`/users/:id`, requireAdmin, (req, res, next) =>
{
    usersModel.findByIdAndDelete(req.params.id)
    .then(data =>
    {
        if(!data)
        {
            next(createError(404, `User not found`))
        }
        else if(data.profilePhotoFilename)
        {
            fs.unlink(`${process.env.UPLOADED_FILES_FOLDER}/${data.profilePhotoFilename}`, () => res.json(data))
        }
        else
        {
            res.json(data)
        }
    })
    .catch(err => next(createError(500, `User was not deleted`)))
})

module.exports = router
