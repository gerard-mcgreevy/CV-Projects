const router = require(`express`).Router()
const createError = require(`http-errors`)
const jwt = require(`jsonwebtoken`)

const ordersModel = require(`../config/models/orders`)
const productsModel = require(`../config/models/products`)
const {verifyToken, requireAdmin, JWT_PRIVATE_KEY} = require(`../config/verifyToken`)

const EMAIL_PATTERN = /^[^@]+@[^@]+\.[a-zA-Z]{2,6}$/
const CARD_NUMBER_PATTERN = /^\d{16}$/
const CARD_EXPIRY_PATTERN = /^\d{2}\/\d{2}$/
const CARD_CVV_PATTERN = /^\d{3,4}$/

const getOptionalUserId = req =>
{
    const authHeader = req.headers.authorization

    if(!authHeader)
    {
        return null
    }

    try
    {
        const decoded = jwt.verify(authHeader.split(` `)[1], JWT_PRIVATE_KEY)
        return decoded.id
    }
    catch(err)
    {
        return null
    }
}

router.post(`/orders`, (req, res, next) =>
{
    const itemsAreValid = Array.isArray(req.body.items) && req.body.items.length > 0 && req.body.items.every(item => item.productId && Number.isInteger(item.quantity) && item.quantity > 0)

    if(!req.body.contactName || !EMAIL_PATTERN.test(req.body.contactEmail))
    {
        next(createError(400, `A valid name and email are required`))
    }
    else if(!itemsAreValid)
    {
        next(createError(400, `Your cart is empty or contains an invalid quantity`))
    }
    else if(!req.body.cardNumber || !CARD_NUMBER_PATTERN.test(req.body.cardNumber.replace(/\s/g, ``)))
    {
        next(createError(400, `Card number must be 16 digits`))
    }
    else if(!req.body.cardExpiry || !CARD_EXPIRY_PATTERN.test(req.body.cardExpiry))
    {
        next(createError(400, `Card expiry must be in MM/YY format`))
    }
    else if(!req.body.cardCvv || !CARD_CVV_PATTERN.test(req.body.cardCvv))
    {
        next(createError(400, `Card CVV must be 3 or 4 digits`))
    }
    else
    {
        Promise.all(req.body.items.map(item => productsModel.findById(item.productId)))
        .then(products =>
        {
            const notFoundIndex = products.findIndex(product => !product)
            const insufficientStockProduct = products.find((product, index) => product && product.stock < req.body.items[index].quantity)

            if(notFoundIndex !== -1)
            {
                next(createError(404, `One of the products in your cart no longer exists`))
            }
            else if(insufficientStockProduct)
            {
                next(createError(409, `Not enough stock for ${insufficientStockProduct.name}`))
            }
            else
            {
                const orderItems = products.map((product, index) => ({
                    product: product._id,
                    name: product.name,
                    quantity: req.body.items[index].quantity,
                    priceAtPurchase: product.price
                }))

                const totalPrice = orderItems.reduce((total, item) => total + (item.priceAtPurchase * item.quantity), 0)

                Promise.all(products.map((product, index) => productsModel.findByIdAndUpdate(product._id, {$inc: {stock: -req.body.items[index].quantity}})))
                .then(() =>
                {
                    ordersModel.create({
                        user: getOptionalUserId(req),
                        contactName: req.body.contactName,
                        contactEmail: req.body.contactEmail,
                        items: orderItems,
                        totalPrice: totalPrice
                    })
                    .then(data => res.json(data))
                    .catch(err => next(createError(500, `Order could not be placed`)))
                })
                .catch(err => next(createError(500, `Order could not be placed`)))
            }
        })
        .catch(err => next(createError(500, `Order could not be placed`)))
    }
})

router.get(`/orders/mine`, verifyToken, (req, res, next) =>
{
    ordersModel.find({user: req.tokenData.id}).sort({createdAt: -1})
    .then(data => res.json(data))
    .catch(err => next(createError(500, `Could not retrieve purchase history`)))
})

router.get(`/orders/user/:id`, requireAdmin, (req, res, next) =>
{
    ordersModel.find({user: req.params.id}).sort({createdAt: -1})
    .then(data => res.json(data))
    .catch(err => next(createError(500, `Could not retrieve purchase history`)))
})

router.patch(`/orders/:id/return`, verifyToken, (req, res, next) =>
{
    ordersModel.findById(req.params.id)
    .then(data =>
    {
        if(!data)
        {
            next(createError(404, `Order not found`))
        }
        else if(!data.user || data.user.toString() !== req.tokenData.id)
        {
            next(createError(403, `You can only return your own orders`))
        }
        else if(data.status === `returned`)
        {
            next(createError(409, `This order has already been returned`))
        }
        else
        {
            Promise.all(data.items.map(item => productsModel.findByIdAndUpdate(item.product, {$inc: {stock: item.quantity}})))
            .then(() =>
            {
                data.status = `returned`
                data.save()
                .then(updatedData => res.json(updatedData))
                .catch(err => next(createError(500, `Return could not be processed`)))
            })
            .catch(err => next(createError(500, `Return could not be processed`)))
        }
    })
    .catch(err => next(createError(500, `Return could not be processed`)))
})

module.exports = router
