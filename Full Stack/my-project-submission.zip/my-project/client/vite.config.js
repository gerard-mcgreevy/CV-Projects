import { defineConfig } from "vite"
import react from "@vitejs/plugin-react"
import { transform } from "esbuild"

const jsxInJsPlugin = () => ({
    name: "jsx-in-js",
    enforce: "pre",
    async transform(code, id)
    {
        const filePath = id.split("?")[0]

        if(filePath.includes("/src/") && filePath.endsWith(".js") && !filePath.includes("node_modules"))
        {
            const result = await transform(code, {
                loader: "jsx",
                jsx: "automatic",
                jsxImportSource: "react",
                sourcefile: filePath
            })

            return {code: result.code, map: result.map}
        }
    }
})

export default defineConfig({
    plugins: [jsxInJsPlugin(), react()],
    optimizeDeps: {
        esbuildOptions: {
            loader: {
                ".js": "jsx"
            }
        }
    },
    server: {
        port: 3000
    }
})
