import React, {useState, useEffect} from "react"
import {BrowserRouter, Switch, Route} from "react-router-dom"
import axios from "axios"

import {Header} from "./components/Header"
import {Home} from "./components/Home"
import {ProductDetail} from "./components/ProductDetail"
import {Cart} from "./components/Cart"
import {Checkout} from "./components/Checkout"
import {Login} from "./components/Login"
import {Register} from "./components/Register"
import {Logout} from "./components/Logout"
import {Profile} from "./components/Profile"
import {PurchaseHistory} from "./components/PurchaseHistory"
import {AdminProducts} from "./components/AdminProducts"
import {AdminUsers} from "./components/AdminUsers"
import {LoggedInRoute} from "./components/LoggedInRoute"
import {AdministratorRoute} from "./components/AdministratorRoute"
import {SERVER_HOST, ACCESS_LEVEL_GUEST} from "./config/global_constants"

if(typeof localStorage.accessLevel === "undefined")
{
    localStorage.name = "GUEST"
    localStorage.accessLevel = ACCESS_LEVEL_GUEST
    localStorage.id = ""
    localStorage.email = ""
    localStorage.profilePhoto = null
    localStorage.token = ""
}

export const App = props =>
{
    const [accessLevel, setAccessLevel] = useState(parseInt(localStorage.accessLevel))
    const [cartItemCount, setCartItemCount] = useState(0)

    const refreshCartCount = () =>
    {
        const cart = localStorage.cart ? JSON.parse(localStorage.cart) : []
        setCartItemCount(cart.reduce((total, item) => total + item.quantity, 0))
    }

    useEffect(() =>
    {
        refreshCartCount()

        if(localStorage.token)
        {
            axios.post(`${SERVER_HOST}/users/refresh_token`, {}, {headers: {Authorization: `Bearer ${localStorage.token}`}})
            .then(res =>
            {
                localStorage.id = res.data.id
                localStorage.name = res.data.name
                localStorage.email = res.data.email
                localStorage.accessLevel = res.data.accessLevel
                localStorage.profilePhoto = res.data.profilePhoto
                localStorage.token = res.data.token

                setAccessLevel(res.data.accessLevel)
            })
            .catch(err =>
            {
                localStorage.name = "GUEST"
                localStorage.accessLevel = ACCESS_LEVEL_GUEST
                localStorage.id = ""
                localStorage.email = ""
                localStorage.profilePhoto = null
                localStorage.token = ""

                setAccessLevel(ACCESS_LEVEL_GUEST)
            })
        }
    }, [])

    return (
        <BrowserRouter>
            <Header accessLevel={accessLevel} cartItemCount={cartItemCount}/>

            <div className="gmcg_app">
                <Switch>
                    <Route exact path="/" render={routeProps => <Home {...routeProps} onCartChange={refreshCartCount}/>}/>
                    <Route exact path="/products/:id" render={routeProps => <ProductDetail {...routeProps} onCartChange={refreshCartCount}/>}/>
                    <Route exact path="/cart" render={routeProps => <Cart {...routeProps} onCartChange={refreshCartCount}/>}/>
                    <Route exact path="/checkout" render={routeProps => <Checkout {...routeProps} onCartChange={refreshCartCount}/>}/>
                    <Route exact path="/login" render={routeProps => <Login {...routeProps} onAuthChange={setAccessLevel}/>}/>
                    <Route exact path="/register" render={routeProps => <Register {...routeProps} onAuthChange={setAccessLevel}/>}/>
                    <LoggedInRoute exact path="/logout" component={Logout} onAuthChange={setAccessLevel}/>
                    <LoggedInRoute exact path="/profile" component={Profile}/>
                    <LoggedInRoute exact path="/purchase_history" component={PurchaseHistory}/>
                    <AdministratorRoute exact path="/admin/products" component={AdminProducts}/>
                    <AdministratorRoute exact path="/admin/users" component={AdminUsers}/>
                    <Route path="*" component={() => <h3 className="gmcg_notFound">Invalid URL. Webpage does not exist</h3>}/>
                </Switch>
            </div>
        </BrowserRouter>
    )
}
