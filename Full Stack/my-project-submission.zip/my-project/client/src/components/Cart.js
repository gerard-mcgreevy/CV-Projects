import React, {useState, useEffect} from "react"
import {Link} from "react-router-dom"

export const Cart = props =>
{
    const [cart, setCart] = useState([])

    useEffect(() =>
    {
        setCart(localStorage.cart ? JSON.parse(localStorage.cart) : [])
    }, [])

    const saveCart = updatedCart =>
    {
        localStorage.cart = JSON.stringify(updatedCart)
        setCart(updatedCart)
        props.onCartChange()
    }

    const handleQuantityChange = (productId, e) =>
    {
        const updatedCart = cart.map(item => item.productId === productId ? {...item, quantity: parseInt(e.target.value)} : item)
        saveCart(updatedCart)
    }

    const handleRemove = productId =>
    {
        const updatedCart = cart.filter(item => item.productId !== productId)
        saveCart(updatedCart)
    }

    const totalPrice = cart.reduce((total, item) => total + (item.price * item.quantity), 0)

    if(cart.length === 0)
    {
        return (
            <div className="gmcg_cartContainer">
                <h1>Your Cart</h1>
                <p>Your cart is empty.</p>
                <Link className="gmcg_secondaryButton" to="/">Continue shopping</Link>
            </div>
        )
    }

    return (
        <div className="gmcg_cartContainer">
            <h1>Your Cart</h1>

            <table className="gmcg_dataTable">
                <thead>
                    <tr>
                        <th>Set</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th> </th>
                    </tr>
                </thead>

                <tbody>
                    {cart.map(item =>
                        <tr key={item.productId}>
                            <td>{item.name}</td>
                            <td>€{item.price}</td>
                            <td><input type="number" min="1" value={item.quantity} onChange={e => handleQuantityChange(item.productId, e)}/></td>
                            <td>€{(item.price * item.quantity).toFixed(2)}</td>
                            <td><button onClick={() => handleRemove(item.productId)}>Remove</button></td>
                        </tr>
                    )}
                </tbody>
            </table>

            <h2>Total: €{totalPrice.toFixed(2)}</h2>

            <Link className="gmcg_secondaryButton" to="/">Continue shopping</Link>
            <Link className="gmcg_greenButton" to="/checkout">Checkout</Link>
        </div>
    )
}
