import React, {useState} from "react"
import {Redirect, Link} from "react-router-dom"
import axios from "axios"
import {Button} from "./Button"
import {SERVER_HOST} from "../config/global_constants"

export const Login = props =>
{
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [errorMessage, setErrorMessage] = useState("")
    const [isLoggedIn, setIsLoggedIn] = useState(false)

    const handleEmailChange = e =>
    {
        setEmail(e.target.value)
    }

    const handlePasswordChange = e =>
    {
        setPassword(e.target.value)
    }

    const handleSubmit = e =>
    {
        if(!email || !password)
        {
            setErrorMessage(`Email and password are required`)
        }
        else
        {
            axios.post(`${SERVER_HOST}/users/login/${encodeURIComponent(email)}/${encodeURIComponent(password)}`)
            .then(res =>
            {
                localStorage.id = res.data.id
                localStorage.name = res.data.name
                localStorage.email = res.data.email
                localStorage.accessLevel = res.data.accessLevel
                localStorage.profilePhoto = res.data.profilePhoto
                localStorage.token = res.data.token

                props.onAuthChange(res.data.accessLevel)
                setIsLoggedIn(true)
            })
            .catch(err => setErrorMessage(err.response ? err.response.data : `Login failed`))
        }
    }

    return (
        <form noValidate={true} id="gmcg_loginForm" className="gmcg_formContainer">
            <h2>Login</h2>

            {isLoggedIn ? <Redirect to="/"/> : null}

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}

            <label>Email</label>
            <input
                name="email"
                type="email"
                placeholder="Email"
                autoComplete="email"
                autoFocus
                value={email}
                onChange={handleEmailChange}
            />

            <label>Password</label>
            <input
                name="password"
                type="password"
                placeholder="Password"
                autoComplete="current-password"
                value={password}
                onChange={handlePasswordChange}
            />

            <Button value="Login" className="gmcg_greenButton" onClick={handleSubmit}/>
            <Link className="gmcg_redButton" to="/">Cancel</Link>
        </form>
    )
}
