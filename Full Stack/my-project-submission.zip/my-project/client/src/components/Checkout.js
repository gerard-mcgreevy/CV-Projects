import React, {useState} from "react"
import {Redirect} from "react-router-dom"
import axios from "axios"
import {Button} from "./Button"
import {SERVER_HOST} from "../config/global_constants"

const EMAIL_PATTERN = /^[^@]+@[^@]+\.[a-zA-Z]{2,6}$/
const CARD_NUMBER_PATTERN = /^\d{16}$/
const CARD_EXPIRY_PATTERN = /^\d{2}\/\d{2}$/
const CARD_CVV_PATTERN = /^\d{3,4}$/

export const Checkout = props =>
{
    const [contactName, setContactName] = useState(localStorage.name !== "GUEST" ? localStorage.name : "")
    const [contactEmail, setContactEmail] = useState(localStorage.email || "")
    const [cardNumber, setCardNumber] = useState("")
    const [cardExpiry, setCardExpiry] = useState("")
    const [cardCvv, setCardCvv] = useState("")
    const [errorMessage, setErrorMessage] = useState("")
    const [isComplete, setIsComplete] = useState(false)

    const cart = localStorage.cart ? JSON.parse(localStorage.cart) : []
    const totalPrice = cart.reduce((total, item) => total + (item.price * item.quantity), 0)

    const handleContactNameChange = e =>
    {
        setContactName(e.target.value)
    }

    const handleContactEmailChange = e =>
    {
        setContactEmail(e.target.value)
    }

    const handleCardNumberChange = e =>
    {
        setCardNumber(e.target.value)
    }

    const handleCardExpiryChange = e =>
    {
        setCardExpiry(e.target.value)
    }

    const handleCardCvvChange = e =>
    {
        setCardCvv(e.target.value)
    }

    const handleSubmit = e =>
    {
        if(!contactName)
        {
            setErrorMessage(`Name is required`)
        }
        else if(!EMAIL_PATTERN.test(contactEmail))
        {
            setErrorMessage(`Please enter a valid email address`)
        }
        else if(!CARD_NUMBER_PATTERN.test(cardNumber.replace(/\s/g, ``)))
        {
            setErrorMessage(`Card number must be 16 digits`)
        }
        else if(!CARD_EXPIRY_PATTERN.test(cardExpiry))
        {
            setErrorMessage(`Card expiry must be in MM/YY format`)
        }
        else if(!CARD_CVV_PATTERN.test(cardCvv))
        {
            setErrorMessage(`Card CVV must be 3 or 4 digits`)
        }
        else
        {
            const headers = localStorage.token ? {Authorization: `Bearer ${localStorage.token}`} : {}

            axios.post(`${SERVER_HOST}/orders`, {
                contactName: contactName,
                contactEmail: contactEmail,
                items: cart.map(item => ({productId: item.productId, quantity: item.quantity})),
                cardNumber: cardNumber,
                cardExpiry: cardExpiry,
                cardCvv: cardCvv
            }, {headers: headers})
            .then(res =>
            {
                setIsComplete(true)
                localStorage.removeItem(`cart`)
                props.onCartChange()
            })
            .catch(err => setErrorMessage(err.response ? err.response.data : `Checkout failed`))
        }
    }

    if(cart.length === 0 && !isComplete)
    {
        return <Redirect to="/cart"/>
    }

    if(isComplete)
    {
        return (
            <div className="gmcg_checkoutContainer">
                <h1>Thank you for your order</h1>
                <p>A confirmation has been sent to {contactEmail}</p>
            </div>
        )
    }

    return (
        <form noValidate={true} id="gmcg_checkoutForm" className="gmcg_formContainer">
            <h1>Checkout</h1>

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}

            <h2>Contact Details</h2>

            <label>Name</label>
            <input name="contactName" type="text" value={contactName} onChange={handleContactNameChange}/>

            <label>Email</label>
            <input name="contactEmail" type="email" value={contactEmail} onChange={handleContactEmailChange}/>

            <h2>Payment Details</h2>

            <label>Card Number</label>
            <input name="cardNumber" type="text" placeholder="1234123412341234" value={cardNumber} onChange={handleCardNumberChange}/>

            <label>Expiry (MM/YY)</label>
            <input name="cardExpiry" type="text" placeholder="MM/YY" value={cardExpiry} onChange={handleCardExpiryChange}/>

            <label>CVV</label>
            <input name="cardCvv" type="text" placeholder="123" value={cardCvv} onChange={handleCardCvvChange}/>

            <h2>Total: €{totalPrice.toFixed(2)}</h2>

            <Button value="Place Order" className="gmcg_greenButton" onClick={handleSubmit}/>
        </form>
    )
}
