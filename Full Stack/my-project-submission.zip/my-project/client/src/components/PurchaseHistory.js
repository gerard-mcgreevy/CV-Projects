import React, {useState, useEffect} from "react"
import axios from "axios"
import {SERVER_HOST} from "../config/global_constants"

export const PurchaseHistory = props =>
{
    const [orders, setOrders] = useState([])
    const [errorMessage, setErrorMessage] = useState("")

    const loadOrders = () =>
    {
        axios.get(`${SERVER_HOST}/orders/mine`, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res => setOrders(res.data))
        .catch(err => setErrorMessage(err.response ? err.response.data : `Could not load purchase history`))
    }

    useEffect(() =>
    {
        loadOrders()
    }, [])

    const handleReturn = orderId =>
    {
        axios.patch(`${SERVER_HOST}/orders/${orderId}/return`, {}, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res => loadOrders())
        .catch(err => setErrorMessage(err.response ? err.response.data : `Return could not be processed`))
    }

    return (
        <div className="gmcg_purchaseHistoryContainer">
            <h1>My Orders</h1>

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}

            {orders.length === 0 ? <p>You have not placed any orders yet.</p> : null}

            {orders.map(order =>
                <div key={order._id} className="gmcg_orderCard">
                    <p>{new Date(order.createdAt).toLocaleDateString()}</p>
                    <p>Status: {order.status}</p>

                    <table className="gmcg_dataTable">
                        <thead>
                            <tr>
                                <th>Set</th>
                                <th>Quantity</th>
                                <th>Price</th>
                            </tr>
                        </thead>

                        <tbody>
                            {order.items.map(item =>
                                <tr key={item.product}>
                                    <td>{item.name}</td>
                                    <td>{item.quantity}</td>
                                    <td>€{item.priceAtPurchase}</td>
                                </tr>
                            )}
                        </tbody>
                    </table>

                    <p>Total: €{order.totalPrice.toFixed(2)}</p>

                    <button disabled={order.status === `returned`} onClick={() => handleReturn(order._id)}>
                        {order.status === `returned` ? `Returned` : `Return Order`}
                    </button>
                </div>
            )}
        </div>
    )
}
