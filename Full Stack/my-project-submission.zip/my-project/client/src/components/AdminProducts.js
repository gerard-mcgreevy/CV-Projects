import React, {useState, useEffect} from "react"
import axios from "axios"
import {SERVER_HOST} from "../config/global_constants"

const EMPTY_FORM = {name: ``, setNumber: ``, theme: ``, description: ``, pieceCount: ``, price: ``, stock: ``}

export const AdminProducts = props =>
{
    const [products, setProducts] = useState([])
    const [editingProductId, setEditingProductId] = useState(null)
    const [formFields, setFormFields] = useState(EMPTY_FORM)
    const [existingImages, setExistingImages] = useState([])
    const [removeImages, setRemoveImages] = useState([])
    const [selectedFiles, setSelectedFiles] = useState([])
    const [errorMessage, setErrorMessage] = useState("")
    const [successMessage, setSuccessMessage] = useState("")

    const loadProducts = () =>
    {
        axios.get(`${SERVER_HOST}/products`)
        .then(res => setProducts(res.data))
        .catch(err => setErrorMessage(err.response ? err.response.data : `Could not load products`))
    }

    useEffect(() =>
    {
        loadProducts()
    }, [])

    const handleFieldChange = e =>
    {
        setFormFields({...formFields, [e.target.name]: e.target.value})
    }

    const handleFileChange = e =>
    {
        setSelectedFiles(Array.from(e.target.files))
    }

    const handleToggleRemoveImage = filename =>
    {
        if(removeImages.includes(filename))
        {
            setRemoveImages(removeImages.filter(name => name !== filename))
        }
        else
        {
            setRemoveImages([...removeImages, filename])
        }
    }

    const handleEditClick = product =>
    {
        setEditingProductId(product._id)
        setFormFields({
            name: product.name,
            setNumber: product.setNumber,
            theme: product.theme,
            description: product.description,
            pieceCount: product.pieceCount,
            price: product.price,
            stock: product.stock
        })
        setExistingImages(product.imageFilenames)
        setRemoveImages([])
        setSelectedFiles([])
        setErrorMessage(``)
        setSuccessMessage(``)
    }

    const handleCancelEdit = () =>
    {
        setEditingProductId(null)
        setFormFields(EMPTY_FORM)
        setExistingImages([])
        setRemoveImages([])
        setSelectedFiles([])
    }

    const handleDelete = productId =>
    {
        axios.delete(`${SERVER_HOST}/products/${productId}`, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res =>
        {
            if(editingProductId === productId)
            {
                handleCancelEdit()
            }

            loadProducts()
        })
        .catch(err => setErrorMessage(err.response ? err.response.data : `Product could not be deleted`))
    }

    const handleQuickStockChange = (productId, newStock) =>
    {
        axios.patch(`${SERVER_HOST}/products/${productId}/stock`, {stock: newStock}, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res => loadProducts())
        .catch(err => setErrorMessage(err.response ? err.response.data : `Stock could not be updated`))
    }

    const handleSubmit = e =>
    {
        setSuccessMessage(``)

        if(!formFields.name || !formFields.setNumber || !formFields.theme || !formFields.description)
        {
            setErrorMessage(`Name, set number, theme and description are required`)
        }
        else if(isNaN(formFields.price) || Number(formFields.price) < 0)
        {
            setErrorMessage(`Price must be a positive number`)
        }
        else if(isNaN(formFields.stock) || Number(formFields.stock) < 0)
        {
            setErrorMessage(`Stock must be a positive number`)
        }
        else
        {
            let formData = new FormData()
            formData.append(`name`, formFields.name)
            formData.append(`setNumber`, formFields.setNumber)
            formData.append(`theme`, formFields.theme)
            formData.append(`description`, formFields.description)
            formData.append(`pieceCount`, formFields.pieceCount)
            formData.append(`price`, formFields.price)
            formData.append(`stock`, formFields.stock)
            formData.append(`removeImageFilenames`, JSON.stringify(removeImages))

            selectedFiles.forEach(file => formData.append(`images`, file))

            const headers = {Authorization: `Bearer ${localStorage.token}`, "Content-type": "multipart/form-data"}
            const request = editingProductId
                ? axios.put(`${SERVER_HOST}/products/${editingProductId}`, formData, {headers: headers})
                : axios.post(`${SERVER_HOST}/products`, formData, {headers: headers})

            request
            .then(res =>
            {
                setSuccessMessage(editingProductId ? `Product updated` : `Product added`)
                handleCancelEdit()
                loadProducts()
            })
            .catch(err => setErrorMessage(err.response ? err.response.data : `Product could not be saved`))
        }
    }

    return (
        <div className="gmcg_adminProductsContainer">
            <h1>Manage Products</h1>

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}
            {successMessage ? <div className="gmcg_formSuccess">{successMessage}</div> : null}

            <form noValidate={true} id="gmcg_productForm" className="gmcg_formContainer">
                <h2>{editingProductId ? `Edit Set` : `Add New Set`}</h2>

                <label>Name</label>
                <input name="name" type="text" value={formFields.name} onChange={handleFieldChange}/>

                <label>Set Number</label>
                <input name="setNumber" type="text" value={formFields.setNumber} onChange={handleFieldChange}/>

                <label>Theme</label>
                <input name="theme" type="text" value={formFields.theme} onChange={handleFieldChange}/>

                <label>Description</label>
                <input name="description" type="text" value={formFields.description} onChange={handleFieldChange}/>

                <label>Piece Count</label>
                <input name="pieceCount" type="number" min="1" value={formFields.pieceCount} onChange={handleFieldChange}/>

                <label>Price</label>
                <input name="price" type="number" min="0" step="0.01" value={formFields.price} onChange={handleFieldChange}/>

                <label>Stock</label>
                <input name="stock" type="number" min="0" value={formFields.stock} onChange={handleFieldChange}/>

                {existingImages.length > 0 ?
                    <div className="gmcg_existingImages">
                        {existingImages.map(filename =>
                            <div key={filename} className="gmcg_existingImage">
                                <img src={`${SERVER_HOST}/uploads/${filename}`} alt=""/>
                                <label>
                                    <input type="checkbox" checked={removeImages.includes(filename)} onChange={() => handleToggleRemoveImage(filename)}/>
                                    Remove
                                </label>
                            </div>
                        )}
                    </div>
                    : null}

                <label>{editingProductId ? `Add More Images` : `Images`}</label>
                <input type="file" accept="image/png, image/jpeg" multiple onChange={handleFileChange}/>

                <button type="button" onClick={handleSubmit}>{editingProductId ? `Save Changes` : `Add Set`}</button>
                {editingProductId ? <button type="button" onClick={handleCancelEdit}>Cancel</button> : null}
            </form>

            <table className="gmcg_dataTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Theme</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th> </th>
                    </tr>
                </thead>

                <tbody>
                    {products.map(product =>
                        <tr key={product._id}>
                            <td>{product.name}</td>
                            <td>{product.theme}</td>
                            <td>€{product.price}</td>
                            <td>
                                <input
                                    type="number"
                                    min="0"
                                    value={product.stock}
                                    onChange={e => handleQuickStockChange(product._id, e.target.value)}
                                />
                            </td>
                            <td>
                                <button onClick={() => handleEditClick(product)}>Edit</button>
                                <button onClick={() => handleDelete(product._id)}>Delete</button>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
    )
}
