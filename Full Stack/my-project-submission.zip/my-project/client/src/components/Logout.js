import React, {useState, useEffect} from "react"
import {Redirect} from "react-router-dom"
import axios from "axios"
import {SERVER_HOST, ACCESS_LEVEL_GUEST} from "../config/global_constants"

export const Logout = props =>
{
    const [isLoggedOut, setIsLoggedOut] = useState(false)

    useEffect(() =>
    {
        axios.post(`${SERVER_HOST}/users/logout`)
        .then(res =>
        {
            localStorage.clear()

            localStorage.name = "GUEST"
            localStorage.accessLevel = ACCESS_LEVEL_GUEST
            localStorage.id = ""
            localStorage.email = ""
            localStorage.profilePhoto = null
            localStorage.token = ""

            props.onAuthChange(ACCESS_LEVEL_GUEST)
            setIsLoggedOut(true)
        })
        .catch(err => setIsLoggedOut(true))
    }, [])

    return (
        <div>
            {isLoggedOut ? <Redirect to="/"/> : null}
        </div>
    )
}
