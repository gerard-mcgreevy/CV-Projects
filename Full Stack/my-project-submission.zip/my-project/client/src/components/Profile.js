import React, {useState} from "react"
import axios from "axios"
import {Button} from "./Button"
import {SERVER_HOST} from "../config/global_constants"

const EMAIL_PATTERN = /^[^@]+@[^@]+\.[a-zA-Z]{2,6}$/

export const Profile = props =>
{
    const [name, setName] = useState(localStorage.name)
    const [email, setEmail] = useState(localStorage.email)
    const [selectedFile, setSelectedFile] = useState(null)
    const [profilePhoto, setProfilePhoto] = useState(localStorage.profilePhoto)
    const [errorMessage, setErrorMessage] = useState("")
    const [successMessage, setSuccessMessage] = useState("")

    const handleNameChange = e =>
    {
        setName(e.target.value)
    }

    const handleEmailChange = e =>
    {
        setEmail(e.target.value)
    }

    const handleFileChange = e =>
    {
        setSelectedFile(e.target.files[0])
    }

    const handleSubmit = e =>
    {
        setSuccessMessage(``)

        if(!name)
        {
            setErrorMessage(`Name is required`)
        }
        else if(!EMAIL_PATTERN.test(email))
        {
            setErrorMessage(`Please enter a valid email address`)
        }
        else
        {
            let formData = new FormData()
            formData.append(`name`, name)
            formData.append(`email`, email)

            if(selectedFile)
            {
                formData.append(`profilePhoto`, selectedFile)
            }

            axios.put(`${SERVER_HOST}/users/${localStorage.id}`, formData, {headers: {Authorization: `Bearer ${localStorage.token}`, "Content-type": "multipart/form-data"}})
            .then(res =>
            {
                localStorage.name = res.data.name
                localStorage.email = res.data.email
                localStorage.profilePhoto = res.data.profilePhoto
                localStorage.token = res.data.token

                setProfilePhoto(res.data.profilePhoto)
                setSelectedFile(null)
                setErrorMessage(``)
                setSuccessMessage(`Profile updated`)
            })
            .catch(err => setErrorMessage(err.response ? err.response.data : `Profile update failed`))
        }
    }

    return (
        <form noValidate={true} id="gmcg_profileForm" className="gmcg_formContainer">
            <h1>Profile</h1>

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}
            {successMessage ? <div className="gmcg_formSuccess">{successMessage}</div> : null}

            {profilePhoto && profilePhoto !== "null" ? <img className="gmcg_profilePhoto" src={`data:;base64,${profilePhoto}`} alt="Profile"/> : null}

            <label>Name</label>
            <input name="name" type="text" value={name} onChange={handleNameChange}/>

            <label>Email</label>
            <input name="email" type="email" value={email} onChange={handleEmailChange}/>

            <label>Change profile photo</label>
            <input type="file" accept="image/png, image/jpeg" onChange={handleFileChange}/>

            <Button value="Save Changes" className="gmcg_greenButton" onClick={handleSubmit}/>
        </form>
    )
}
