import React, {useState, useEffect} from "react"
import axios from "axios"
import {SERVER_HOST, ACCESS_LEVEL_GUEST, ACCESS_LEVEL_NORMAL_USER, ACCESS_LEVEL_ADMIN} from "../config/global_constants"

const ACCESS_LEVEL_NAMES = {
    [ACCESS_LEVEL_GUEST]: `Guest`,
    [ACCESS_LEVEL_NORMAL_USER]: `Normal User`,
    [ACCESS_LEVEL_ADMIN]: `Administrator`
}

export const AdminUsers = props =>
{
    const [users, setUsers] = useState([])
    const [selectedUserId, setSelectedUserId] = useState(null)
    const [selectedUserOrders, setSelectedUserOrders] = useState([])
    const [errorMessage, setErrorMessage] = useState("")

    const loadUsers = () =>
    {
        axios.get(`${SERVER_HOST}/users`, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res => setUsers(res.data))
        .catch(err => setErrorMessage(err.response ? err.response.data : `Could not load users`))
    }

    useEffect(() =>
    {
        loadUsers()
    }, [])

    const handleDelete = userId =>
    {
        axios.delete(`${SERVER_HOST}/users/${userId}`, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res =>
        {
            if(selectedUserId === userId)
            {
                setSelectedUserId(null)
            }

            loadUsers()
        })
        .catch(err => setErrorMessage(err.response ? err.response.data : `User could not be deleted`))
    }

    const handleViewPurchases = userId =>
    {
        setSelectedUserId(userId)
        setErrorMessage(``)

        axios.get(`${SERVER_HOST}/orders/user/${userId}`, {headers: {Authorization: `Bearer ${localStorage.token}`}})
        .then(res => setSelectedUserOrders(res.data))
        .catch(err => setErrorMessage(err.response ? err.response.data : `Could not load purchase history`))
    }

    return (
        <div className="gmcg_adminUsersContainer">
            <h1>Manage Users</h1>

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}

            <table className="gmcg_dataTable">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Access Level</th>
                        <th> </th>
                    </tr>
                </thead>

                <tbody>
                    {users.map(user =>
                        <tr key={user._id}>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>{ACCESS_LEVEL_NAMES[user.accessLevel]}</td>
                            <td>
                                <button onClick={() => handleViewPurchases(user._id)}>View Purchases</button>
                                <button onClick={() => handleDelete(user._id)}>Delete</button>
                            </td>
                        </tr>
                    )}
                </tbody>
            </table>

            {selectedUserId ?
                <div className="gmcg_userPurchaseHistory">
                    <h2>Purchase History</h2>

                    {selectedUserOrders.length === 0 ? <p>No purchases</p> : null}

                    {selectedUserOrders.map(order =>
                        <div key={order._id} className="gmcg_orderCard">
                            <p>{new Date(order.createdAt).toLocaleDateString()} - {order.status} - €{order.totalPrice.toFixed(2)}</p>

                            <table className="gmcg_dataTable">
                                <thead>
                                    <tr>
                                        <th>Set</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {order.items.map(item =>
                                        <tr key={item.product}>
                                            <td>{item.name}</td>
                                            <td>{item.quantity}</td>
                                            <td>€{item.priceAtPurchase}</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    )}
                </div>
                : null}
        </div>
    )
}
