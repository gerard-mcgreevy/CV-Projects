import React, {useState, useEffect} from "react"
import {Link} from "react-router-dom"
import axios from "axios"
import {SERVER_HOST} from "../config/global_constants"

export const Home = props =>
{
    const [products, setProducts] = useState([])
    const [themes, setThemes] = useState([])
    const [search, setSearch] = useState("")
    const [theme, setTheme] = useState("All Themes")
    const [sortBy, setSortBy] = useState("name")
    const [sortDirection, setSortDirection] = useState("asc")

    useEffect(() =>
    {
        axios.get(`${SERVER_HOST}/products`)
        .then(res =>
        {
            const uniqueThemes = res.data.map(product => product.theme).filter((themeName, index, allThemes) => allThemes.indexOf(themeName) === index)
            setThemes(uniqueThemes)
        })
        .catch(err => console.log(err))
    }, [])

    useEffect(() =>
    {
        axios.get(`${SERVER_HOST}/products?search=${encodeURIComponent(search)}&theme=${encodeURIComponent(theme)}&sortBy=${sortBy}&sortDirection=${sortDirection}`)
        .then(res => setProducts(res.data))
        .catch(err => console.log(err))
    }, [search, theme, sortBy, sortDirection])

    const handleSearchChange = e =>
    {
        setSearch(e.target.value)
    }

    const handleThemeChange = e =>
    {
        setTheme(e.target.value)
    }

    const handleSortByChange = e =>
    {
        setSortBy(e.target.value)
    }

    const handleSortDirectionChange = e =>
    {
        setSortDirection(e.target.value)
    }

    const handleAddToCart = product =>
    {
        const cart = localStorage.cart ? JSON.parse(localStorage.cart) : []
        const existingItem = cart.find(item => item.productId === product._id)

        if(existingItem)
        {
            existingItem.quantity = existingItem.quantity + 1
        }
        else
        {
            cart.push({productId: product._id, name: product.name, price: product.price, imageFilename: product.imageFilenames[0], quantity: 1})
        }

        localStorage.cart = JSON.stringify(cart)
        props.onCartChange()
    }

    return (
        <div className="gmcg_productListContainer">
            <h1>Lego Sets</h1>

            <div className="gmcg_productFilters">
                <input type="text" placeholder="Search by name" value={search} onChange={handleSearchChange}/>

                <select value={theme} onChange={handleThemeChange}>
                    <option value="All Themes">All Themes</option>
                    {themes.map(themeOption => <option key={themeOption} value={themeOption}>{themeOption}</option>)}
                </select>

                <select value={sortBy} onChange={handleSortByChange}>
                    <option value="name">Name</option>
                    <option value="price">Price</option>
                    <option value="stock">Stock</option>
                </select>

                <select value={sortDirection} onChange={handleSortDirectionChange}>
                    <option value="asc">Ascending</option>
                    <option value="desc">Descending</option>
                </select>
            </div>

            <div className="gmcg_productGrid">
                {products.map(product =>
                    <div key={product._id} className="gmcg_productCard">
                        <Link to={`/products/${product._id}`}>
                            {product.imageFilenames[0] ? <img src={`${SERVER_HOST}/uploads/${product.imageFilenames[0]}`} alt={product.name}/> : null}
                            <h3>{product.name}</h3>
                        </Link>

                        <p>{product.theme}</p>
                        <p>€{product.price}</p>
                        <p>{product.stock > 0 ? `${product.stock} in stock` : `Out of stock`}</p>

                        <button disabled={product.stock === 0} onClick={() => handleAddToCart(product)}>Add to Cart</button>
                    </div>
                )}
            </div>
        </div>
    )
}
