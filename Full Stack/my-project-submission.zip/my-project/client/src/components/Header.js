import React from "react"
import {Link} from "react-router-dom"
import {ACCESS_LEVEL_NORMAL_USER, ACCESS_LEVEL_ADMIN} from "../config/global_constants"

export const Header = props =>
{
    return (
        <div className="gmcg_nav">
            <Link className="gmcg_navBrand" to="/">Lego Store</Link>

            <Link className="gmcg_navCart" to="/cart">Cart ({props.cartItemCount})</Link>

            {props.accessLevel >= ACCESS_LEVEL_ADMIN ?
                <div className="gmcg_navAdminLinks">
                    <Link to="/admin/products">Manage Products</Link>
                    <Link to="/admin/users">Manage Users</Link>
                </div>
                : null}

            {props.accessLevel >= ACCESS_LEVEL_NORMAL_USER ?
                <div className="gmcg_navUserLinks">
                    <Link to="/purchase_history">My Orders</Link>
                    <Link to="/profile">Profile</Link>
                    <Link to="/logout">Log Out</Link>
                </div>
                :
                <div className="gmcg_navGuestLinks">
                    <Link to="/login">Log In</Link>
                    <Link to="/register">Register</Link>
                </div>
            }
        </div>
    )
}
