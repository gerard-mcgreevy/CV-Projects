import React, {useState, useEffect} from "react"
import {Link} from "react-router-dom"
import axios from "axios"
import {SERVER_HOST} from "../config/global_constants"

export const ProductDetail = props =>
{
    const [product, setProduct] = useState(null)
    const [selectedImageIndex, setSelectedImageIndex] = useState(0)
    const [quantity, setQuantity] = useState(1)
    const [addedMessage, setAddedMessage] = useState("")

    useEffect(() =>
    {
        axios.get(`${SERVER_HOST}/products/${props.match.params.id}`)
        .then(res => setProduct(res.data))
        .catch(err => console.log(err))
    }, [props.match.params.id])

    const handleQuantityChange = e =>
    {
        setQuantity(parseInt(e.target.value))
    }

    const handleAddToCart = () =>
    {
        const cart = localStorage.cart ? JSON.parse(localStorage.cart) : []
        const existingItem = cart.find(item => item.productId === product._id)

        if(existingItem)
        {
            existingItem.quantity = existingItem.quantity + quantity
        }
        else
        {
            cart.push({productId: product._id, name: product.name, price: product.price, imageFilename: product.imageFilenames[0], quantity: quantity})
        }

        localStorage.cart = JSON.stringify(cart)
        props.onCartChange()
        setAddedMessage(`Added to cart`)
    }

    if(!product)
    {
        return (
            <div className="gmcg_productDetailContainer">
                <p>Loading...</p>
            </div>
        )
    }

    return (
        <div className="gmcg_productDetailContainer">
            <Link className="gmcg_secondaryButton" to="/">Back to all sets</Link>

            <div className="gmcg_productDetailImages">
                {product.imageFilenames.length > 0 ?
                    <img className="gmcg_productDetailMainImage" src={`${SERVER_HOST}/uploads/${product.imageFilenames[selectedImageIndex]}`} alt={product.name}/>
                    : null}

                <div className="gmcg_productDetailThumbnails">
                    {product.imageFilenames.map((imageFilename, index) =>
                        <img
                            key={imageFilename}
                            className="gmcg_productDetailThumbnail"
                            src={`${SERVER_HOST}/uploads/${imageFilename}`}
                            alt={product.name}
                            onClick={() => setSelectedImageIndex(index)}
                        />
                    )}
                </div>
            </div>

            <h1>{product.name}</h1>
            <p>{product.theme}</p>
            <p>{product.description}</p>
            <p>{product.pieceCount} pieces</p>
            <p>€{product.price}</p>
            <p>{product.stock > 0 ? `${product.stock} in stock` : `Out of stock`}</p>

            {addedMessage ? <div className="gmcg_formSuccess">{addedMessage}</div> : null}

            <input type="number" min="1" max={product.stock} value={quantity} onChange={handleQuantityChange} disabled={product.stock === 0}/>

            <button disabled={product.stock === 0} onClick={handleAddToCart}>Add to Cart</button>
        </div>
    )
}
