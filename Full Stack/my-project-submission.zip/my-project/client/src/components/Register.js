import React, {useState} from "react"
import {Redirect, Link} from "react-router-dom"
import axios from "axios"
import {Button} from "./Button"
import {SERVER_HOST} from "../config/global_constants"

const EMAIL_PATTERN = /^[^@]+@[^@]+\.[a-zA-Z]{2,6}$/
const PASSWORD_PATTERN = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[£!#€$%^&*]).{10,}$/

export const Register = props =>
{
    const [name, setName] = useState("")
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const [confirmPassword, setConfirmPassword] = useState("")
    const [selectedFile, setSelectedFile] = useState(null)
    const [errorMessage, setErrorMessage] = useState("")
    const [isRegistered, setIsRegistered] = useState(false)

    const handleNameChange = e =>
    {
        setName(e.target.value)
    }

    const handleEmailChange = e =>
    {
        setEmail(e.target.value)
    }

    const handlePasswordChange = e =>
    {
        setPassword(e.target.value)
    }

    const handleConfirmPasswordChange = e =>
    {
        setConfirmPassword(e.target.value)
    }

    const handleFileChange = e =>
    {
        setSelectedFile(e.target.files[0])
    }

    const handleSubmit = e =>
    {
        if(!name)
        {
            setErrorMessage(`Name is required`)
        }
        else if(!EMAIL_PATTERN.test(email))
        {
            setErrorMessage(`Please enter a valid email address`)
        }
        else if(!PASSWORD_PATTERN.test(password))
        {
            setErrorMessage(`Password must be at least ten characters long and contain a lowercase letter, an uppercase letter, a digit and one of the following characters (£!#€$%^&*)`)
        }
        else if(password !== confirmPassword)
        {
            setErrorMessage(`Passwords do not match`)
        }
        else
        {
            let formData = new FormData()

            if(selectedFile)
            {
                formData.append(`profilePhoto`, selectedFile)
            }

            axios.post(`${SERVER_HOST}/users/register/${encodeURIComponent(name)}/${encodeURIComponent(email)}/${encodeURIComponent(password)}`, formData, {headers: {"Content-type": "multipart/form-data"}})
            .then(res =>
            {
                localStorage.id = res.data.id
                localStorage.name = res.data.name
                localStorage.email = res.data.email
                localStorage.accessLevel = res.data.accessLevel
                localStorage.profilePhoto = res.data.profilePhoto
                localStorage.token = res.data.token

                props.onAuthChange(res.data.accessLevel)
                setIsRegistered(true)
            })
            .catch(err => setErrorMessage(err.response ? err.response.data : `Registration failed`))
        }
    }

    return (
        <form noValidate={true} id="gmcg_registerForm" className="gmcg_formContainer">
            <h2>New User Registration</h2>

            {isRegistered ? <Redirect to="/"/> : null}

            {errorMessage ? <div className="gmcg_formError">{errorMessage}</div> : null}

            <label>Name</label>
            <input name="name" type="text" placeholder="Name" autoComplete="name" autoFocus value={name} onChange={handleNameChange}/>

            <label>Email</label>
            <input name="email" type="email" placeholder="Email" autoComplete="email" value={email} onChange={handleEmailChange}/>

            <label>Password</label>
            <input
                name="password"
                type="password"
                placeholder="Password"
                autoComplete="new-password"
                title="Password must be at least ten characters long and contain a lowercase letter, an uppercase letter, a digit and one of the following characters (£!#€$%^&*)"
                value={password}
                onChange={handlePasswordChange}
            />

            <label>Confirm password</label>
            <input name="confirmPassword" type="password" placeholder="Confirm password" autoComplete="new-password" value={confirmPassword} onChange={handleConfirmPasswordChange}/>

            <label>Profile photo (optional)</label>
            <input type="file" accept="image/png, image/jpeg" onChange={handleFileChange}/>

            <Button value="Register" className="gmcg_greenButton" onClick={handleSubmit}/>
            <Link className="gmcg_redButton" to="/">Cancel</Link>
        </form>
    )
}
